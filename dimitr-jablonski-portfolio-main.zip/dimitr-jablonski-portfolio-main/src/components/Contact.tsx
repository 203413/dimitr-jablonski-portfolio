
import React, { useState, useRef } from 'react';
import { Mail, Phone, Send, MapPin, Clock, CheckCircle2, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from './ui/card';
import ScrollReveal from './ScrollReveal';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      console.log('Form submitted:', formData);
      setIsSubmitting(false);
      setSubmitted(true);
      
      // Reset form
      if (formRef.current) {
        formRef.current.reset();
      }
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: '',
      });
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setSubmitted(false);
      }, 5000);
    }, 1500);
  };

  return (
    <section id="contact" className="section-padding bg-charcoal text-white relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-64 h-64 bg-purple/30 rounded-full blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute top-1/4 -right-32 w-80 h-80 bg-purple-light/30 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute -bottom-16 left-1/4 w-72 h-72 bg-purple-neon/20 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto relative z-10">
        <ScrollReveal>
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
              <span className="relative z-10">Skontaktuj się ze mną</span>
              <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-purple-light to-purple opacity-70"></span>
            </h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Masz pytania lub chcesz omówić projekt? Wypełnij formularz, a odezwę się tak szybko, jak to możliwe.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 max-w-5xl mx-auto">
          <ScrollReveal delay={200} className="lg:col-span-2 space-y-6">
            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden bg-navy/70 backdrop-blur-sm">
              <div className="h-3 bg-gradient-to-r from-purple to-purple-light"></div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-6 relative inline-block">
                  <span className="relative z-10 text-white">Informacje kontaktowe</span>
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-purple/50"></span>
                </h3>
                
                <div className="space-y-5">
                  <div className="flex items-center group">
                    <div className="w-12 h-12 rounded-full bg-purple/20 flex items-center justify-center mr-4 group-hover:bg-purple/40 transition-all">
                      <Mail className="text-purple-light group-hover:text-white transition-colors" size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Email</p>
                      <a href="mailto:kontakt@dimitrjablonski.pl" className="text-white hover:text-purple-light transition-colors font-medium">
                        kontakt@dimitrjablonski.pl
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center group">
                    <div className="w-12 h-12 rounded-full bg-purple/20 flex items-center justify-center mr-4 group-hover:bg-purple/40 transition-all">
                      <Phone className="text-purple-light group-hover:text-white transition-colors" size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Telefon</p>
                      <a href="tel:+48123456789" className="text-white hover:text-purple-light transition-colors font-medium">
                        +48 123 456 789
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center group">
                    <div className="w-12 h-12 rounded-full bg-purple/20 flex items-center justify-center mr-4 group-hover:bg-purple/40 transition-all">
                      <MapPin className="text-purple-light group-hover:text-white transition-colors" size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Lokalizacja</p>
                      <p className="text-white font-medium">Gdańsk, Polska</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center group">
                    <div className="w-12 h-12 rounded-full bg-purple/20 flex items-center justify-center mr-4 group-hover:bg-purple/40 transition-all">
                      <Clock className="text-purple-light group-hover:text-white transition-colors" size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Dostępność</p>
                      <p className="text-white font-medium">Pon-Pt: 9:00 - 17:00</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-white/10">
                  <h4 className="text-lg font-medium mb-3 relative inline-block">
                    <span className="relative z-10 text-white">O mnie</span>
                    <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-purple/30"></span>
                  </h4>
                  <p className="text-gray-300">
                    Nazywam się Dimitr Jabłoński. Mam 20 lat i jestem studentem Politechniki Gdańskiej na kierunku Inżynieria Biomedyczna. 
                    Tworzeniem stron internetowych zajmuję się od kilku lat. 
                    Moją pasją jest IT oraz motoryzacja, aktualnie zbieram na swoje wymarzone auto.
                  </p>
                </div>
              </CardContent>
            </Card>
          </ScrollReveal>
          
          <ScrollReveal delay={400} className="lg:col-span-3">
            <Card className="border-none shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden bg-navy/70 backdrop-blur-sm">
              <div className="h-3 bg-gradient-to-r from-purple-light to-purple"></div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-6 relative inline-block">
                  <span className="relative z-10 text-white">Wyślij wiadomość</span>
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-purple/50"></span>
                </h3>
                
                {submitted ? (
                  <div className="bg-green-900/30 text-green-300 p-5 rounded-lg mb-6 flex items-center shadow-inner border border-green-500/20">
                    <CheckCircle2 className="mr-3 text-green-400" size={24} />
                    <div>
                      <h4 className="font-semibold mb-1 flex items-center">
                        Wiadomość wysłana <Sparkles className="ml-2 text-purple-light" size={16} />
                      </h4>
                      <p>Dziękuję! Twoja wiadomość została wysłana. Odpowiem najszybciej jak to możliwe.</p>
                    </div>
                  </div>
                ) : null}
                
                <form ref={formRef} onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <label htmlFor="name" className="block text-sm font-medium text-gray-300">
                        Imię i nazwisko
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-white/10 rounded-md focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent transition-all bg-white/5 text-white"
                        placeholder="Jan Kowalski"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-white/10 rounded-md focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent transition-all bg-white/5 text-white"
                        placeholder="jan@example.com"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-300">
                      Temat
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      required
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-white/10 rounded-md focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent transition-all bg-white/5 text-white"
                      placeholder="Zapytanie o projekt strony..."
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-300">
                      Wiadomość
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      required
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-white/10 rounded-md focus:outline-none focus:ring-2 focus:ring-purple focus:border-transparent transition-all bg-white/5 text-white resize-none"
                      placeholder="Opisz szczegóły swojego projektu..."
                    />
                  </div>
                  
                  <div>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={cn(
                        "w-full flex items-center justify-center px-6 py-3 rounded-md text-white font-medium transition-all",
                        "bg-gradient-to-r from-purple to-purple-light hover:from-purple-dark hover:to-purple relative overflow-hidden group",
                        "transform hover:-translate-y-0.5 active:translate-y-0 shadow-lg shadow-purple/20",
                        isSubmitting && "opacity-70 cursor-not-allowed"
                      )}
                    >
                      <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-purple-light to-purple opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                      {isSubmitting ? (
                        <span className="flex items-center relative z-10">
                          <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Wysyłanie...
                        </span>
                      ) : (
                        <span className="flex items-center relative z-10">
                          <Send className="mr-2" size={18} />
                          Wyślij wiadomość
                        </span>
                      )}
                    </button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default Contact;
