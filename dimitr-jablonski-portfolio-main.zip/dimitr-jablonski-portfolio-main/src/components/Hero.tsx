
import React, { useState, useEffect } from "react";
import { ArrowDown } from "lucide-react";
import { cn } from "@/lib/utils";

const AnimatedText = ({ text }: { text: string }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(true);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="overflow-hidden relative">
      <span
        className={cn(
          "block transition-all duration-700 transform",
          visible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
        )}
      >
        {text}
      </span>
    </div>
  );
};

const Hero = () => {
  const [loaded, setLoaded] = useState(false);
  
  useEffect(() => {
    setLoaded(true);
  }, []);

  return (
    <section 
      id="home" 
      className="relative min-h-screen flex flex-col justify-center hero-gradient overflow-hidden"
    >
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-navy/90 to-purple/30"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3882&q=80')] bg-cover bg-center opacity-20"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-8 z-10 pt-20">
        <div className="max-w-4xl mx-auto text-center md:text-left">
          <p className={cn(
            "text-purple-light mb-2 font-medium transition-all duration-1000",
            loaded ? "opacity-100" : "opacity-0 translate-y-4"
          )}>
            Web Developer
          </p>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
            <AnimatedText text="Tworzę nowoczesne" />
            <span className="block mt-1 text-purple-light">
              <AnimatedText text="strony internetowe" />
            </span>
          </h1>
          <p className={cn(
            "text-white/80 text-lg md:text-xl max-w-2xl mx-auto md:mx-0 mb-8 transition-all duration-1000 delay-300",
            loaded ? "opacity-100" : "opacity-0 translate-y-4"
          )}>
            Projektuję i rozwijam strony internetowe, sklepy e-commerce oraz platformy kursowe,
            które są szybkie, łatwe w obsłudze i zbudowane zgodnie z najlepszymi praktykami.
          </p>
          
          <div className={cn(
            "flex flex-col sm:flex-row items-center gap-4 justify-center md:justify-start transition-all duration-1000 delay-500",
            loaded ? "opacity-100" : "opacity-0 translate-y-4"
          )}>
            <a 
              href="#portfolio" 
              className="btn btn-primary w-full sm:w-auto rounded-full px-8 py-3 text-sm font-medium tracking-wider hover:scale-105 transition-transform"
            >
              Zobacz moje projekty
            </a>
            <a 
              href="#contact" 
              className="btn btn-outline w-full sm:w-auto rounded-full px-8 py-3 text-sm font-medium tracking-wider hover:scale-105 transition-transform"
            >
              Skontaktuj się
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-10">
        <a 
          href="#portfolio" 
          className="flex flex-col items-center text-white/70 hover:text-white transition-colors"
          aria-label="Przejdź niżej"
        >
          <span className="text-sm mb-2 font-light">Zobacz więcej</span>
          <ArrowDown className={cn(
            "animate-bounce", 
            loaded ? "opacity-100" : "opacity-0"
          )} />
        </a>
      </div>
    </section>
  );
};

export default Hero;
