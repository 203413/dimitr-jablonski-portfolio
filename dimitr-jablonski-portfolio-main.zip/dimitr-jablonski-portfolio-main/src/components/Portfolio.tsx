import React, { useState, useEffect } from 'react';
import { ExternalLink, Github } from 'lucide-react';
import { cn } from '@/lib/utils';

type Project = {
  id: number;
  title: string;
  description: string;
  tags: string[];
  category: string[];
  image: string;
  demoLink?: string;
  githubLink?: string;
};

const projects: Project[] = [
  {
    id: 1,
    title: 'E-commerce dla lokalnego biznesu',
    description: 'Kompleksowy sklep internetowy z systemem płatności, zarządzaniem zamówieniami i integracją produktów.',
    tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    category: ['e-commerce'],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2426&q=80',
    demoLink: '#',
  },
  {
    id: 2,
    title: 'Platforma kursów online',
    description: 'System zarządzania treścią edukacyjną z modułami dla kursantów i administratorów.',
    tags: ['Next.js', 'TypeScript', 'PostgreSQL', 'AWS'],
    category: ['course', 'website'],
    image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=4076&q=80',
    demoLink: '#',
    githubLink: '#',
  },
  {
    id: 3,
    title: 'Portfolio dla fotografa',
    description: 'Responsywna strona portfolio z galerią zdjęć i formularzem kontaktowym.',
    tags: ['HTML/CSS', 'JavaScript', 'GreenSock'],
    category: ['website'],
    image: 'https://images.unsplash.com/photo-1481887328591-3e277530862e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1580&q=80',
    demoLink: '#',
  },
  {
    id: 4,
    title: 'System rezerwacji dla restauracji',
    description: 'Aplikacja do zarządzania rezerwacjami, menu i zamówieniami online.',
    tags: ['Vue.js', 'Firebase', 'Tailwind CSS'],
    category: ['website', 'e-commerce'],
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=4846&q=80',
    demoLink: '#',
    githubLink: '#',
  },
  {
    id: 5,
    title: 'Dashboard analityczny',
    description: 'Interaktywny dashboard do analizy danych sprzedażowych z wykresami i raportami.',
    tags: ['React', 'D3.js', 'Node.js', 'Express'],
    category: ['website', 'course'],
    image: 'https://images.unsplash.com/photo-1483058712412-4245e9b90334?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=5760&q=80',
    demoLink: '#',
  },
];

const Portfolio = () => {
  const [filter, setFilter] = useState<string>('all');
  const [visibleProjects, setVisibleProjects] = useState<Project[]>(projects);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('portfolio');
    if (section) {
      observer.observe(section);
    }

    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  useEffect(() => {
    if (filter === 'all') {
      setVisibleProjects(projects);
    } else {
      const filtered = projects.filter(project => 
        project.category.includes(filter)
      );
      setVisibleProjects(filtered);
    }
  }, [filter]);

  return (
    <section id="portfolio" className="section-padding bg-charcoal text-white">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white relative inline-block">
            <span className="relative z-10">Moje projekty</span>
            <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-purple-light to-purple opacity-70"></span>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Zobacz wybrane projekty, które stworzyłem dla klientów z różnych branż.
            Każdy projekt jest unikalny i dostosowany do potrzeb klienta.
          </p>
        </div>

        <div className="flex justify-center flex-wrap gap-3 mb-12">
          <button
            onClick={() => setFilter('all')}
            className={cn(
              "px-4 py-2 rounded-full transition-all",
              filter === 'all' 
                ? "bg-purple text-white shadow-lg shadow-purple/30" 
                : "bg-navy text-gray-300 hover:bg-navy/80"
            )}
          >
            Wszystkie
          </button>
          <button
            onClick={() => setFilter('website')}
            className={cn(
              "px-4 py-2 rounded-full transition-all",
              filter === 'website' 
                ? "bg-purple text-white shadow-lg shadow-purple/30" 
                : "bg-navy text-gray-300 hover:bg-navy/80"
            )}
          >
            Strony www
          </button>
          <button
            onClick={() => setFilter('e-commerce')}
            className={cn(
              "px-4 py-2 rounded-full transition-all",
              filter === 'e-commerce' 
                ? "bg-purple text-white shadow-lg shadow-purple/30" 
                : "bg-navy text-gray-300 hover:bg-navy/80"
            )}
          >
            Sklepy e-commerce
          </button>
          <button
            onClick={() => setFilter('course')}
            className={cn(
              "px-4 py-2 rounded-full transition-all",
              filter === 'course' 
                ? "bg-purple text-white shadow-lg shadow-purple/30" 
                : "bg-navy text-gray-300 hover:bg-navy/80"
            )}
          >
            Platformy kursowe
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {visibleProjects.map((project, index) => (
            <div 
              key={project.id} 
              className={cn(
                "bg-navy rounded-xl overflow-hidden shadow-md card-hover transform transition-all duration-500 border border-white/5 hover:border-purple/30",
                isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8",
                `delay-[${index * 100}ms]`
              )}
            >
              <div className="relative overflow-hidden group h-48">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4 w-full flex justify-between items-center">
                    <div className="flex space-x-2">
                      {project.demoLink && (
                        <a 
                          href={project.demoLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/40 transition-colors"
                        >
                          <ExternalLink size={16} className="text-white" />
                        </a>
                      )}
                      {project.githubLink && (
                        <a 
                          href={project.githubLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/40 transition-colors"
                        >
                          <Github size={16} className="text-white" />
                        </a>
                      )}
                    </div>
                    <span className="text-sm text-white">Zobacz więcej</span>
                  </div>
                </div>
              </div>
              <div className="p-5">
                <h3 className="text-xl font-semibold mb-2 text-white relative inline-block">
                  <span className="relative z-10">{project.title}</span>
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-purple-light/70"></span>
                </h3>
                <p className="text-gray-300 text-sm mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, i) => (
                    <span 
                      key={i}
                      className="text-xs bg-charcoal text-gray-300 px-2 py-1 rounded-md border border-white/10 hover:border-purple/30 transition-colors"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
