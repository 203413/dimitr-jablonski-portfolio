import React, { useEffect, useState } from 'react';
import { 
  LayoutGrid, ShoppingCart, BookOpen, Search, 
  Code, Settings, Smartphone, ArrowRight, 
  CheckCircle, Clock, PenTool, Zap, Monitor, GitBranch
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

type Service = {
  icon: React.ElementType;
  title: string;
  description: string;
  features?: string[];
};

const services: Service[] = [
  {
    icon: LayoutGrid,
    title: 'Strony internetowe',
    description: 'Tworzę nowoczesne, responsywne strony internetowe dla firm i osób prywatnych.',
    features: [
      'Responsywny design dostosowany do wszystkich urządzeń',
      'Optymalizacja pod kątem szybkości ładowania',
      'Dostosowanie do wytycznych SEO',
      'Intuicyjny system zarządzania treścią'
    ]
  },
  {
    icon: ShoppingCart,
    title: 'Sklepy e-commerce',
    description: 'Kompleksowe rozwiązania e-commerce z integracją płatności i systemem zarządzania.',
    features: [
      'Integracja z popularnymi bramkami płatności',
      'System zarządzania zamówieniami i produktami',
      'Śledzenie analityki i zachowań użytkowników',
      'Generowanie raportów sprzedażowych'
    ]
  },
  {
    icon: BookOpen,
    title: 'Platformy kursowe',
    description: 'Platformy edukacyjne z systemem zarządzania treścią i modułami dla uczniów.',
    features: [
      'System autoryzacji i dostępu do treści',
      'Interaktywne moduły edukacyjne',
      'Śledzenie postępów uczniów',
      'Integracja z płatnościami za kursy'
    ]
  },
  {
    icon: Search,
    title: 'Optymalizacja SEO',
    description: 'Zwiększ widoczność swojej strony w wyszukiwarkach i przyciągnij więcej klientów.',
    features: [
      'Audyt SEO istniejącej strony',
      'Optymalizacja treści pod kątem słów kluczowych',
      'Analiza konkurencji i strategia pozycjonowania',
      'Regularne raporty z wynikami'
    ]
  },
  {
    icon: Code,
    title: 'Niestandardowe aplikacje',
    description: 'Dedykowane aplikacje webowe dopasowane do indywidualnych potrzeb biznesowych.',
    features: [
      'Konsultacja i analiza wymagań projektu',
      'Tworzenie interfejsu użytkownika UX/UI',
      'Integracja z istniejącymi systemami',
      'Testowanie i wdrożenie aplikacji'
    ]
  },
  {
    icon: Settings,
    title: 'Wsparcie techniczne',
    description: 'Ciągłe wsparcie techniczne, aktualizacje i konserwacja istniejących stron.',
    features: [
      'Regularne aktualizacje zabezpieczeń',
      'Monitoring wydajności strony',
      'Rozwiązywanie problemów technicznych',
      'Wprowadzanie nowych funkcjonalności'
    ]
  }
];

type Process = {
  number: number;
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
};

const process: Process[] = [
  {
    number: 1,
    title: 'Konsultacja z klientem',
    description: 'Dogłębne zrozumienie potrzeb, celów projektu i grupy docelowej.',
    icon: PenTool,
    color: 'bg-purple/10 text-purple'
  },
  {
    number: 2,
    title: 'Koncepcja wizualna',
    description: 'Projektowanie dopasowanego rozwiązania zgodnie z identyfikacją wizualną.',
    icon: Monitor,
    color: 'bg-green-500/10 text-green-500'
  },
  {
    number: 3,
    title: 'Rozwój',
    description: 'Kodowanie i implementacja zaprojektowanych rozwiązań.',
    icon: Code,
    color: 'bg-blue-500/10 text-blue-500'
  },
  {
    number: 4,
    title: 'Testy i optymalizacja',
    description: 'Zapewnienie wydajności i funkcjonalności na wszystkich urządzeniach.',
    icon: GitBranch,
    color: 'bg-orange-500/10 text-orange-500'
  },
  {
    number: 5,
    title: 'Dostarczenie projektu',
    description: 'Finalizacja projektu i wprowadzenie ostatnich poprawek.',
    icon: CheckCircle,
    color: 'bg-purple-neon/10 text-purple-neon'
  },
  {
    number: 6,
    title: 'Wsparcie',
    description: 'Ciągłe wsparcie, przyszłe aktualizacje i rozbudowa funkcjonalności.',
    icon: Clock,
    color: 'bg-teal-500/10 text-teal-500'
  }
];

const Services = () => {
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('services');
    if (section) {
      observer.observe(section);
    }

    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  return (
    <section id="services" className="section-padding bg-charcoal text-white">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white relative inline-block">
            <span className="relative z-10">Co oferuję</span>
            <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-purple-light to-purple opacity-70"></span>
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Oferuję kompleksowe usługi w zakresie tworzenia stron internetowych,
            sklepów e-commerce i platform kursowych. Każdy projekt jest dopasowany
            do indywidualnych potrzeb klienta.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div 
                key={index} 
                className={cn(
                  "bg-navy p-6 rounded-xl border border-white/5 hover:border-purple/30 transition-all duration-300 shadow-lg hover:shadow-purple/20",
                  isInView ? "animate-fade-in" : "opacity-0",
                  `[animation-delay:${index * 100}ms]`
                )}
              >
                <div className="w-16 h-16 rounded-lg bg-purple/10 flex items-center justify-center mb-5">
                  <Icon className="text-purple-light" size={30} />
                </div>
                <h3 className="text-2xl font-semibold mb-3 text-white">{service.title}</h3>
                <p className="text-gray-300 mb-5">{service.description}</p>
                
                {service.features && (
                  <Accordion type="single" collapsible className="border-t border-white/10 pt-2">
                    <AccordionItem value="features" className="border-b-0">
                      <AccordionTrigger className="text-sm text-purple-light hover:text-purple-neon py-2">
                        Zobacz szczegóły
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-2 mt-2">
                          {service.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm">
                              <Zap size={16} className="text-purple-neon mt-1 shrink-0" />
                              <span className="text-gray-300">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                )}
              </div>
            );
          })}
        </div>
        
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-white relative inline-block">
              <span className="relative z-10">Proces współpracy</span>
              <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-purple-light to-purple opacity-70"></span>
            </h3>
            <p className="text-gray-300 max-w-2xl mx-auto mt-4">
              Skuteczny proces, który zapewnia wysoką jakość i zadowolenie klienta
              na każdym etapie realizacji projektu.
            </p>
          </div>
          
          <div className="relative">
            {/* Desktop version with connecting arrows */}
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-purple/20 via-purple/40 to-purple/20 transform -translate-y-1/2 z-0"></div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {process.map((step, index) => {
                const Icon = step.icon;
                return (
                  <div 
                    key={index}
                    className={cn(
                      "relative z-10",
                      isInView ? "animate-fade-in" : "opacity-0",
                      `[animation-delay:${200 + index * 100}ms]`
                    )}
                  >
                    <div className="bg-navy p-6 rounded-xl border border-white/10 hover:border-purple/30 transition-all duration-300 shadow-lg hover:shadow-purple/20 h-full flex flex-col">
                      <div className="flex items-center mb-4">
                        <div className={`flex items-center justify-center w-12 h-12 rounded-full ${step.color} mr-4`}>
                          <Icon size={20} />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-purple-light font-bold text-sm">ETAP {step.number}</span>
                          <h4 className="text-xl font-semibold text-white">{step.title}</h4>
                        </div>
                      </div>
                      <p className="text-gray-300">{step.description}</p>
                      
                      {/* Arrow positioning for desktop */}
                      {index < process.length - 1 && index % 3 !== 2 && (
                        <div className="hidden lg:flex absolute top-1/2 -right-4 transform -translate-y-1/2 z-20">
                          <div className="bg-navy rounded-full p-1 border border-purple/30">
                            <ArrowRight className="text-purple-light" size={16} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="bg-navy p-8 rounded-2xl border border-white/5 shadow-lg mt-20">
          <h3 className="text-2xl font-bold mb-8 text-center text-white relative inline-block mx-auto">
            <span className="relative z-10">Idealnie dopasowane do każdego ekranu</span>
            <span className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-purple-light to-purple opacity-70"></span>
          </h3>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <div className="text-center md:text-right md:w-1/3">
              <h4 className="text-xl font-semibold mb-2 text-white">Komputery</h4>
              <p className="text-gray-300">
                Pełnowymiarowe doświadczenie z wszystkimi funkcjonalnościami, dopasowane do większych ekranów.
              </p>
            </div>
            
            <div className="flex items-end justify-center gap-4 md:w-1/3 relative">
              {/* Glow effect behind devices */}
              <div className="absolute bottom-0 w-full h-3/4 bg-gradient-to-t from-purple/20 to-transparent rounded-full blur-xl"></div>
            
              {/* Mobile phone mockup */}
              <div className="w-16 h-32 bg-navy rounded-xl relative border border-white/10 z-10 overflow-hidden shadow-lg transform rotate-[-3deg]">
                <div className="absolute inset-1 rounded-lg overflow-hidden">
                  <div className="w-full h-2 bg-purple-light/30 rounded-t-lg"></div>
                  <div className="p-1">
                    <div className="w-full h-2 bg-white/20 rounded-full mt-1"></div>
                    <div className="w-3/4 h-2 bg-white/20 rounded-full mt-1"></div>
                    <div className="w-full h-8 bg-white/10 rounded-md mt-2"></div>
                    <div className="flex gap-1 mt-2">
                      <div className="w-2 h-2 bg-purple-light/50 rounded-full"></div>
                      <div className="w-2 h-2 bg-white/20 rounded-full"></div>
                      <div className="w-2 h-2 bg-white/20 rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Tablet mockup */}
              <div className="w-24 h-40 bg-navy rounded-xl relative border border-white/10 z-10 overflow-hidden shadow-lg">
                <div className="absolute inset-1 rounded-lg overflow-hidden">
                  <div className="w-full h-2 bg-purple-light/30 rounded-t-lg"></div>
                  <div className="p-1">
                    <div className="w-full h-3 bg-white/20 rounded-full mt-1"></div>
                    <div className="w-full h-3 bg-white/15 rounded-full mt-2"></div>
                    <div className="w-full h-12 bg-white/10 rounded-md mt-2"></div>
                    <div className="grid grid-cols-2 gap-1 mt-2">
                      <div className="h-4 bg-white/10 rounded"></div>
                      <div className="h-4 bg-white/10 rounded"></div>
                      <div className="h-4 bg-white/10 rounded"></div>
                      <div className="h-4 bg-purple-light/40 rounded"></div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Desktop mockup */}
              <div className="w-32 h-48 bg-navy rounded-xl relative border border-white/10 z-10 overflow-hidden shadow-lg transform rotate-[3deg]">
                <div className="absolute inset-1 rounded-lg overflow-hidden">
                  <div className="w-full h-2 bg-purple-light/30 rounded-t-lg"></div>
                  <div className="p-2">
                    <div className="flex justify-between mb-2">
                      <div className="w-1/2 h-3 bg-white/20 rounded-full"></div>
                      <div className="flex gap-1">
                        <div className="w-2 h-2 rounded-full bg-red-400/60"></div>
                        <div className="w-2 h-2 rounded-full bg-yellow-400/60"></div>
                        <div className="w-2 h-2 rounded-full bg-green-400/60"></div>
                      </div>
                    </div>
                    <div className="w-full h-4 bg-white/10 rounded-full mb-2"></div>
                    <div className="w-full h-16 bg-white/10 rounded-md"></div>
                    <div className="grid grid-cols-3 gap-1 mt-2">
                      <div className="h-5 bg-white/10 rounded"></div>
                      <div className="h-5 bg-purple-light/40 rounded"></div>
                      <div className="h-5 bg-white/10 rounded"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center md:text-left md:w-1/3">
              <h4 className="text-xl font-semibold mb-2 text-white">Urządzenia mobilne</h4>
              <p className="text-gray-300">
                Zoptymalizowane doświadczenie dla smartfonów i tabletów, zaprojektowane z myślą o użytkownikach mobilnych.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
