
import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { cn } from '@/lib/utils';

type Testimonial = {
  id: number;
  name: string;
  position: string;
  company: string;
  content: string;
  image?: string;
};

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Kamil Nowak',
    position: 'Właściciel',
    company: 'BioEko Sklep',
    content: 'Jestem bardzo zadowolony z profesjonalizmu i efektów pracy. Strona mojego sklepu internetowego działa świetnie, jest szybka i przyjazna dla użytkowników. Zdecydowanie polecam!',
    image: 'https://i.pravatar.cc/150?img=12',
  },
  {
    id: 2,
    name: 'Anna Kowalska',
    position: 'Marketing Manager',
    company: 'EducationPro',
    content: 'Współpraca przebiegała bardzo sprawnie. Otrzymaliśmy dokładnie to, czego potrzebowaliśmy - platformę kursową, która jest intuicyjna zarówno dla nas, jak i dla naszych kursantów.',
    image: 'https://i.pravatar.cc/150?img=10',
  },
  {
    id: 3,
    name: 'Marek Wiśniewski',
    position: 'CEO',
    company: 'TechnoSolutions',
    content: 'Dimitr wykazał się dużą wiedzą i zaangażowaniem. Nasze wymagania zostały spełnione, a nawet przekroczone. Strona internetowa, którą stworzył, znacznie poprawiła naszą obecność online.',
    image: 'https://i.pravatar.cc/150?img=11',
  },
];

const Testimonials = () => {
  const [current, setCurrent] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const next = () => {
    if (!isAnimating) {
      setIsAnimating(true);
      setCurrent((prev) => (prev + 1) % testimonials.length);
      setTimeout(() => setIsAnimating(false), 500);
    }
  };

  const prev = () => {
    if (!isAnimating) {
      setIsAnimating(true);
      setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
      setTimeout(() => setIsAnimating(false), 500);
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        } else {
          setIsInView(false);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('testimonials');
    if (section) {
      observer.observe(section);
    }

    return () => {
      if (section) {
        observer.unobserve(section);
      }
    };
  }, []);

  useEffect(() => {
    if (isInView) {
      intervalRef.current = setInterval(next, 5000);
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isInView, current, isAnimating]);

  return (
    <section id="testimonials" className="section-padding bg-navy text-white">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Co mówią klienci</h2>
          <p className="text-white/70 max-w-2xl mx-auto">
            Zobacz opinie klientów, którzy zdecydowali się na współpracę ze mną
            i skorzystali z moich usług w zakresie tworzenia stron internetowych.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 z-10">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
              aria-label="Poprzednie opinie"
            >
              <ChevronLeft size={20} className="text-white" />
            </button>
          </div>

          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${current * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div 
                  key={testimonial.id} 
                  className="min-w-full px-4"
                >
                  <div className={cn(
                    "bg-white/5 backdrop-blur-sm p-8 rounded-2xl relative", 
                    isInView ? "animate-fade-in" : "opacity-0"
                  )}>
                    <Quote className="absolute top-6 left-6 text-purple/20" size={48} />
                    
                    <div className="relative z-10">
                      <p className="text-lg mb-6 text-white/90 italic">
                        "{testimonial.content}"
                      </p>
                      
                      <div className="flex items-center">
                        {testimonial.image && (
                          <div className="mr-4">
                            <img 
                              src={testimonial.image} 
                              alt={testimonial.name} 
                              className="w-12 h-12 rounded-full object-cover"
                            />
                          </div>
                        )}
                        <div>
                          <h4 className="font-semibold">{testimonial.name}</h4>
                          <p className="text-sm text-white/70">
                            {testimonial.position}, {testimonial.company}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="absolute -right-8 top-1/2 transform -translate-y-1/2 z-10">
            <button
              onClick={next}
              className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
              aria-label="Następne opinie"
            >
              <ChevronRight size={20} className="text-white" />
            </button>
          </div>

          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrent(index)}
                className={cn(
                  "w-3 h-3 rounded-full transition-colors",
                  index === current ? "bg-purple" : "bg-white/30 hover:bg-white/50"
                )}
                aria-label={`Przejdź do opinii ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
