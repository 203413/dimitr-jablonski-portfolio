
export const initScrollReveal = (): void => {
  const revealElements = document.querySelectorAll('.reveal');
  
  const revealOnScroll = () => {
    const windowHeight = window.innerHeight;
    const revealPoint = 150;

    revealElements.forEach((element) => {
      const revealTop = element.getBoundingClientRect().top;
      
      if (revealTop < windowHeight - revealPoint) {
        element.classList.add('reveal-visible');
      }
    });
  };

  // Initial check on load
  window.addEventListener('load', revealOnScroll);
  
  // Check on scroll
  window.addEventListener('scroll', revealOnScroll);
};
